Press pack: the 5 November 2026 sell-off study (donttrade)

Study: https://donttrade.ca/research/5-november-2026-sell-off/
Published 6 Nov 2026; updated 7 Nov 2026. Cite as: donttrade (2026). The 5 November 2026 sell-off: force-closed wallets on Hyperliquid. https://donttrade.ca/research/5-november-2026-sell-off/

What is in this pack
  ONE-PAGE-SUMMARY.txt  the key facts as sentences, and how to stay accurate
  charts/               three charts as PNG images (title, source, address and licence are inside each image)
  data/                 the CSVs behind the charts, and the market-by-market breakdown with what each market tracks
  ANALYSIS-PLAN.md      the method, written down and hashed before the data was opened
  The plan's SHA-256: 21ce82c3bebd3044b0f43bceb4bb09626aad90262a375a0591274e55f364d704

Licences
  Study text: CC BY-NC 4.0.
  Charts and the chart files in this pack: CC BY 4.0. Credit: Chart: donttrade.ca (CC BY 4.0).
  Data counts and code: CC BY 4.0. Source data: Ironflow, Hyperliquid Trades and Liquidations, CC BY 4.0.

Contact
  research@donttrade.ca, subject “Press”. Reply within 1 business day; interviews by email only.
  SVG versions of each chart and the plan, hash, code and run log are on the study page: https://donttrade.ca/research/5-november-2026-sell-off/
